# AdvWebDev
Form Validation in level 8

This website takes Name , Email , Password , Date of Birth as inputs and displays the entries in the below entries table.

